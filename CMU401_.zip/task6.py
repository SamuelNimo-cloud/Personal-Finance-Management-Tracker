#Includes previous code as context
import sys

# --- Configuration ---
EXPENSE_FILENAME = "expenses.txt"

class Expense:
    
    #Represents a single expense item with details.
    
    def __init__(self, amount: float, description: str, category: str):
        # The amount spent
        self.amount = amount
        # A brief description of the expense
        self.description = description
        # The category (e.g., Food, Transport, Entertainment)
        self.category = category

    def __str__(self):
        #Returns a formatted string representation for display.
        return f"[{self.category:<13}] ${self.amount:7.2f} - {self.description}"

    def to_csv_line(self) -> str:
        
        #Formats the expense for saving to a file. Removes commas from the description
        #to prevent issues with the CSV-like structure.
        
        clean_description = self.description.replace(',', '').strip()
        return f"{self.amount},{clean_description},{self.category}"


class WeeklyBudget:
    
    #Stores a list of Expense objects and provides methods for financial tracking.
    
    def __init__(self):
        # Expenses are stored in a simple list
        self.expenses = []

    def add_expense(self, expense: Expense):
        
        #Adds a new Expense object to the budget tracker.
        
        self.expenses.append(expense)
        print(f"💰 Added: {expense.description} (${expense.amount:.2f})")

    def show_totals(self) -> float:
        
        #Calculates and returns the total amount of all recorded expenses.
        
        total = sum(expense.amount for expense in self.expenses)
        return total
    
    def count_expenses(self) -> int:
        
        #Counts the total number of individual expenses recorded.
        
        return len(self.expenses)

    def find_expenses(self, query: str) -> list[Expense]:
        
        #Finds expenses where the description or category contains the query string (case-insensitive).
        #Returns a list of matching Expense objects.
        
        found = []
        q_lower = query.lower()
        for expense in self.expenses:
            if q_lower in expense.description.lower() or q_lower in expense.category.lower():
                found.append(expense)
        return found
    
    def remove_expense(self, description: str) -> bool:
        
        #Removes the first expense found matching the description exactly (case-insensitive).
        #Returns True if an expense was removed, False otherwise.
        
        # Find the index of the expense to remove
        remove_index = -1
        description_lower = description.lower()
        for i, expense in enumerate(self.expenses):
            if expense.description.lower() == description_lower:
                remove_index = i
                break
        
        if remove_index != -1:
            del self.expenses[remove_index]
            return True
        return False
    
    def sort_expenses_by_amount(self, reverse: bool = True):
        
        #Sorts expenses by amount. By default, sorts high to low (reverse=True).
        #This sorts the internal list of expenses in place.
        
        self.expenses.sort(key=lambda expense: expense.amount, reverse=reverse)
        print("\n⬇️ Expenses sorted by amount (High to Low).")

    def display_expenses(self):
        
        #Displays all recorded expenses nicely.
        
        if not self.expenses:
            print("\n-- No expenses recorded this week. --")
            return

        print("\n--- ALL RECORDED EXPENSES ---")
        for expense in self.expenses:
            print(f"| {expense}")
        print("-" * 35)
        print(f"Total Count: {self.count_expenses()}")


    # --- New File Handling Functions ---

    def save_to_file(self, filename: str = EXPENSE_FILENAME):
        
        #Saves all current expenses to a simple text file.
        
        if not self.expenses:
            print("\n-- No expenses to save. File will be empty or overwritten. --")

        try:
            with open(filename, 'w') as f:
                for expense in self.expenses:
                    f.write(expense.to_csv_line() + '\n')
            print(f"\n✅ Success: All {self.count_expenses()} expenses saved to '{filename}'.")
        except IOError:
            print(f"\n❌ Error: Could not write to file '{filename}'.")

    def load_from_file(self, filename: str = EXPENSE_FILENAME):
        
        #Reads expenses back from the file and populates the budget list.
        
        self.expenses = []  # Clear current list before loading
        loaded_count = 0
        
        try:
            with open(filename, 'r') as f:
                for line in f:
                    parts = line.strip().split(',', 2)
                    if len(parts) == 3:
                        try:
                            amount = float(parts[0])
                            description = parts[1]
                            category = parts[2]
                            self.expenses.append(Expense(amount, description, category))
                            loaded_count += 1
                        except ValueError:
                            print(f"⚠️ Skipping invalid line: {line.strip()}")
            print(f"\n✅ Loaded {loaded_count} expenses from '{filename}'.")
        except FileNotFoundError:
            print(f"\n⚠️ File '{filename}' not found. Starting with an empty budget.")
        except Exception as e:
            print(f"\n❌ Error loading file: {e}")


    # --- New Reporting Function ---

    def generate_report(self):
        
        #Creates a simple weekly report showing totals by category (Spending Tree).
        
        if not self.expenses:
            print("\n-- No expenses recorded to generate a report. --")
            return

        category_totals = {}
        for expense in self.expenses:
            category_totals[expense.category] = category_totals.get(expense.category, 0.0) + expense.amount
            
        grand_total = self.show_totals()

        print("\n--- 📊 WEEKLY SPENDING REPORT (Spending Tree) 📊 ---")
        print(f"Total Expenses: **${grand_total:.2f}**\n")

        # Sort categories by total amount (high to low)
        sorted_categories = sorted(category_totals.items(), key=lambda item: item[1], reverse=True)

        for category, total in sorted_categories:
            percentage = (total / grand_total) * 100 if grand_total > 0 else 0
            # Display a simple "spending tree" format
            print(f"🌳 {category.upper():<15} | ${total:7.2f} ({percentage:.1f}%)")
            
        print("-" * 45)
        print(f"TOTAL: ${grand_total:.2f}")


# --- Interactive Helper Functions ---

def get_expense_input() -> Expense | None:
    #Handles interactive input for a single expense.
    print("\n--- Enter New Expense Details ---")
    
    while True:
        try:
            amount = float(input("Enter amount spent (e.g., 15.50): $"))
            if amount <= 0:
                print("Amount must be positive.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a numerical value for the amount.")
            
    description = input("Enter a brief description: ").strip()
    if not description:
        print("Description cannot be empty. Returning to menu.")
        return None
        
    category_options = ["Food", "Transport", "Entertainment", "Other"]
    category = input(f"Enter category ({'/'.join(category_options)}): ").strip().capitalize()
    
    # Simple validation for category
    if category not in category_options:
        print(f"Category not recognized. Defaulting to 'Other'.")
        category = "Other"
        
    return Expense(amount, description, category)


# --- Basic Menu System ---

def display_menu():
    #Prints the main menu options.
    print("\n" + "="*40)
    print("      PERSONAL FINANCE TRACKER MENU")
    print("="*40)
    print("1: Add New Expense")
    print("2: Show All Expenses")
    print("3: Show Weekly Report (Category Totals)")
    print("4: Find Expense by Description/Category")
    print("5: Remove Expense by Description")
    print("6: Sort Expenses by Amount")
    print("7: Save Expenses to File")
    print("8: Load Expenses from File")
    print("0: Exit Program")
    print("-" * 40)

def main_menu():
    #Main loop for the expense tracker application.
    budget = WeeklyBudget()
    print(f"Welcome to the Expense Tracker!")
    budget.load_from_file() # Load data automatically on startup

    while True:
        display_menu()
        choice = input("Enter your choice (0-8): ").strip()

        if choice == '1':
            new_expense = get_expense_input()
            if new_expense:
                budget.add_expense(new_expense)
        
        elif choice == '2':
            budget.display_expenses()
            
        elif choice == '3':
            budget.generate_report()
            
        elif choice == '4':
            query = input("Enter keyword to search (description or category): ").strip()
            found = budget.find_expenses(query)
            if found:
                print(f"\n🔎 Found {len(found)} matching expenses:")
                for expense in found:
                    print(f"  - {expense}")
            else:
                print(f"\n-- No expenses found matching '{query}'. --")
                
        elif choice == '5':
            desc_to_remove = input("Enter the **exact description** of the expense to remove: ").strip()
            if budget.remove_expense(desc_to_remove):
                print(f"\n🗑️ Successfully removed expense: '{desc_to_remove}'")
            else:
                print(f"\n❌ Expense with description '{desc_to_remove}' not found.")
       #Use of elif for other menu options         
        elif choice == '6':
            budget.sort_expenses_by_amount(reverse=True)
            budget.display_expenses()
            
        elif choice == '7':
            budget.save_to_file()
            
        elif choice == '8':
            budget.load_from_file()
            
        elif choice == '0':
            print("\nSaving expenses before exit...")
            budget.save_to_file()
            print("Thank you for tracking your finances! Goodbye.")
            sys.exit(0)
            
        else:
            print("\n⚠️ Invalid choice. Please enter a number from 0 to 8.")

#If this script is run directly, start the main menu
if __name__ == "__main__":
    main_menu()

#Writeup:

#This enhanced Personal Finance Tracker application allows users to manage their weekly expenses interactively.
#Users can add, view, find, remove, sort, save, and load expenses, as well as generate a weekly spending report.
#Building a personal finance expense tracker app helped me develop my understanding of Python and
# programming logic. I used classes and the **init** method to organise different types of expenses,
#  which made the code clearer and easier to manage. While developing the app, I tested the program
#  regularly and fixed errors, such as issues with function order and user input. This process 
# improved my debugging skills and attention to detail. I also used external resources, including
#  Gemini, to research concepts and check my understanding. Overall, the project increased my 
# confidence in writing structured code and applying object-oriented programming principles in 
# a practical way.
