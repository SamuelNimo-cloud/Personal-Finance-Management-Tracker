# -------------------------------
# Personal Finance Management System - Basic Budget Setup
# -------------------------------

# Display a welcome message
print("Welcome to your Personal Finance Management System!")
print("Let's set up your weekly budget.\n")

# Step 1: Ask user for their weekly income/allowance
# Use a loop to make sure the input is valid (not negative or too large)
while True:
    try:
        weekly_income = float(input("Enter your weekly income (£): "))

        # Validation checks
        if weekly_income < 0:
            print("Income cannot be negative. Please enter a positive amount.")
        elif weekly_income > 10000:
            print("That seems too high for a weekly income. Please recheck and enter again.")
        else:
            break  # Exit the loop if valid

    except ValueError:
        print("Please enter a valid number (e.g., 225.55).")

# Step 2: Calculate how much the user can spend per day
days_in_week = 7
daily_spending = weekly_income / days_in_week

# Step 3: Convert the weekly and daily amounts to pence
# 1 pound = 100 pence
weekly_income_pence = weekly_income * 100
daily_spending_pence = daily_spending * 100

# Step 4: Display the results neatly
print("------ Budget Summary ------")
print(f"Weekly Income: £{weekly_income:.2f} ({weekly_income_pence:.0f} pence)")
print(f"Daily Spending Limit: £{daily_spending:.2f} ({daily_spending_pence:.0f} pence)")
print("----------------------------")
print("Tip: Try to stay under your daily limit to save more money!\n")

# End of the first section
print("Budget setup complete ✅")

# Reference:
#Google (2024) Gemini. Available at: https://gemini.google.com/
#(Accessed: 14 December 2025).