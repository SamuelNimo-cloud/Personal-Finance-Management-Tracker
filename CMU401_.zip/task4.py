# Simple Expense and Budget Classes for Tracking

class Expense:
    
    #Represents a single expense item with details.
    
    def __init__(self, amount: float, description: str, category: str):
        # The amount spent
        self.amount = amount
        # A brief description of the expense
        self.description = description
        # The category (e.g., Food, Transport, Entertainment)
        self.category = category

    def __str__(self):
        #Returns a string representation of the Expense object."""
        return f"[{self.category:<13}] ${self.amount:7.2f} - {self.description}"


class WeeklyBudget:
    
    #Stores a list of Expense objects and provides methods for basic financial tracking.
    
    def __init__(self):
        # Initialise an empty list to hold all expenses
        self.expenses = []

    def add_expense(self, expense: Expense):
        
        #Adds a new Expense object to the budget tracker.
        
        self.expenses.append(expense)
        print(f"💰 Added: {expense.description} (${expense.amount:.2f})")

    def show_totals(self) -> float:
        
        #Calculates and returns the total amount of all recorded expenses.
        
        total = sum(expense.amount for expense in self.expenses)
        return total

    def display_expenses(self):
        
        #Displays all recorded expenses nicely, grouped by category for readability.
        
        if not self.expenses:
            print("\n-- No expenses recorded this week. --")
            return

        print("\n--- WEEKLY EXPENSE BREAKDOWN ---")
        
        # Group expenses by category
        categories = {}
        for expense in self.expenses:
            if expense.category not in categories:
                categories[expense.category] = []
            categories[expense.category].append(expense)

        # Display expenses category by category
        for category, expense_list in categories.items():
            category_total = sum(e.amount for e in expense_list)
            print(f"\n[{category.upper()} - Total: ${category_total:.2f}]")
            print("-" * (len(category) + 20))
            for expense in expense_list:
                print(f"  - ${expense.amount:.2f}: {expense.description}")

        # Display the grand total at the end
        grand_total = self.show_totals()
        print("\n" + "="*30)
        print(f"✨ GRAND WEEKLY TOTAL: ${grand_total:.2f}")
        print("="*30)


if __name__ == "__main__":
    # Example usage demonstration
    
    # 1. Create a WeeklyBudget instance
    my_budget = WeeklyBudget()

    # 2. Add some expenses
    my_budget.add_expense(Expense(amount=12.50, description="Lunch at cafe", category="Food"))
    my_budget.add_expense(Expense(amount=4.75, description="Bus fare to work", category="Transport"))
    my_budget.add_expense(Expense(amount=35.00, description="Movie night out", category="Entertainment"))
    my_budget.add_expense(Expense(amount=5.00, description="Coffee and pastry", category="Food"))
    my_budget.add_expense(Expense(amount=75.00, description="New headphones", category="Other"))

    # 3. Display all expenses nicely
    my_budget.display_expenses()
    
    # 4. Show the grand total
    final_total = my_budget.show_totals()
    # The total is also shown in display_expenses, but this demonstrates the method
    print(f"\nFinal Total from show_totals() method: ${final_total:.2f}")

    
# Reference:
#Google (2024) Gemini. Available at: https://gemini.google.com/
#(Accessed: 14 December 2025).