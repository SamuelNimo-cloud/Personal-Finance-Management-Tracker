# --- Daily Expense Tracker Application ---

# Set a fixed daily budget for the tracker to use for comparison
DAILY_BUDGET = 100.00
CATEGORIES = ["food", "transport", "entertainment", "other"]
# Define an Expenses class to hold expense data
class Expenses:
    

    #Using init method to initialize the class with expense data
    def __init__(self, day: str, food: float, transport: float, entertainment: float, other: float):
        self.day = day
        self.food = food
        self.transport = transport
        self.entertainment = entertainment
        self.other = other

    # Helper method to calculate the total spent
    def get_total(self):
        return self.food + self.transport + self.entertainment + self.other
    
    # Helper method to get expenses as a dictionary for easier iteration
    def to_dict(self):
        return {
            "food": self.food,
            "transport": self.transport,
            "entertainment": self.entertainment,
            "other": self.other
        }

# --- Functions for Interaction and Logic (Daily) ---

def get_daily_expense():
    
   # Prompts the user to enter expenses for each category and handles invalid input.
    #Returns an Expenses object populated with the user's input.
    
    print(f"\n--- Enter Today's Expenses ---")
    
    # Define the categories to prompt for
    expenses = {}

    for category in CATEGORIES:
        while True:
            try:
                # Ask user for input and convert to a float to allow decimals
                amount = float(input(f"Enter expense for {category.capitalize()} (e.g., 25.50): $"))
                if amount < 0:
                    print("Expense cannot be negative. Please try again.")
                    continue
                expenses[category] = amount
                break
            except ValueError:
                # Handle cases where the user enters non-numeric text
                print("Invalid input. Please enter a numerical value.")

    # In a real app, 'Today's Date' would be used here.
    return Expenses(
        "Today's Entry",
        expenses["food"],
        expenses["transport"],
        expenses["entertainment"],
        expenses["other"]
    )


def check_budget(expenses: Expenses, budget: float):
    
    #Compares the total expenses against the daily budget and displays the results.
    
    total_spent = expenses.get_total()
    remaining_budget = budget - total_spent

    print("\n--- Daily Budget Report ---")
    print(f"Total Daily Budget: ${budget:.2f}")
    print(f"Total Spent Today:  ${total_spent:.2f}")
    
    # Check if they're over/under budget for the day
    if remaining_budget >= 0:
        # Show remaining budget
        print(f"\n✅ Great job! You are **UNDER** budget.")
        print(f"Remaining Budget: **${remaining_budget:.2f}**")
    else:
        # Display simple warnings if overspending
        overspent = abs(remaining_budget)
        print(f"**WARNING!** You are **OVER** budget by **${overspent:.2f}**.")
        print("💡 Simple Warning: Consider reviewing your spending, especially in the Entertainment or Other categories, to stay on track tomorrow.")


# Functions for Weekly Analysis

def calculate_weekly_totals(weekly_data: list[Expenses]):
    
    #Calculates the total amount spent across all categories and days in the week.
    #Returns a dictionary of category totals and the grand total.
    
    weekly_totals = {category: 0.0 for category in CATEGORIES}
    grand_total = 0.0
    
    for day_expense in weekly_data:
        day_data = day_expense.to_dict()
        for category, amount in day_data.items():
            weekly_totals[category] += amount
            grand_total += amount
            
    return weekly_totals, grand_total

def find_biggest_expense(weekly_data: list[Expenses]):
    
    #Finds the single largest category expense across all days in the weekly data.
    #Returns the category, amount, and the day it occurred.
   
    max_expense = 0.0
    max_category = ""
    max_day = ""

    for day_expense in weekly_data:
        day_data = day_expense.to_dict()
        for category, amount in day_data.items():
            if amount > max_expense:
                max_expense = amount
                max_category = category
                max_day = day_expense.day
                
    return max_category, max_expense, max_day

def count_category_spending_days(weekly_data: list[Expenses]):
   
    #Counts how many days an expense was recorded (amount > 0) in each category
   # over the week.
   
    category_counts = {category: 0 for category in CATEGORIES}
    
    for day_expense in weekly_data:
        day_data = day_expense.to_dict()
        for category, amount in day_data.items():
            if amount > 0:
                category_counts[category] += 1
                
    return category_counts

# --- Utility Functions ---

def is_lucky_number(n: int) -> bool:
    
    #function to check if a number is "lucky." 
    #A number is considered lucky if it is a multiple of 7 or ends in 7.
    
    if not isinstance(n, (int, float)):
        return False
        
    n = int(n) # Convert float to int for the check
    
    # Check if the number is a multiple of 7
    is_multiple_of_7 = (n % 7 == 0)
    
    # Check if the last digit is 7
    ends_in_7 = (n % 10 == 7)
    
    return is_multiple_of_7 or ends_in_7

def reverse_description(description: str) -> str:
    
    #Simple function to reverse an expense description (like a palindrome concept).
    
    return description[::-1]


#Sample Data for Weekly Functions Demonstration 

# This simulates a week of tracking to demonstrate the weekly functions.
WEEKLY_DATA = [
    Expenses("Monday", 15.50, 8.00, 0.00, 10.00),
    Expenses("Tuesday", 30.00, 5.00, 25.50, 2.00),
    Expenses("Wednesday", 20.00, 0.00, 0.00, 5.00),
    Expenses("Thursday", 40.00, 15.00, 10.00, 0.00),
    Expenses("Friday", 22.50, 12.00, 50.00, 15.00),
    Expenses("Saturday", 5.00, 0.00, 30.00, 0.00),
    Expenses("Sunday", 10.00, 0.00, 0.00, 5.00),
]


# --- Main Application Execution ---

if __name__ == "__main__":
    print(f"🎯 Running Daily Expense Tracker! (Budget set to ${DAILY_BUDGET:.2f} today)")
    
    # 1. Ask user to enter daily expenses
    expenses_today = get_daily_expense()
    
    # Process and display the daily budget status
    check_budget(expenses_today, DAILY_BUDGET)

    print("\n" + "="*50)
    print("--- WEEKLY ANALYSIS DEMONSTRATION ---")
    print("Using 7 days of sample data to demonstrate analysis functions.")
    print("="*50)

    # Calculate Weekly Totals
    weekly_totals, grand_total = calculate_weekly_totals(WEEKLY_DATA)
    print("\n📈 Weekly Spending Totals:")
    for category, total in weekly_totals.items():
        print(f"  - {category.capitalize()}: ${total:.2f}")
    print(f"  **GRAND TOTAL SPENT: ${grand_total:.2f}**")

    # Find the Biggest Expense
    max_cat, max_amount, max_day = find_biggest_expense(WEEKLY_DATA)
    print("\n🔍 Biggest Single Expense Category:")
    print(f"  - **{max_cat.capitalize()}** at **${max_amount:.2f}** (on {max_day})")

    # Count Category Spending Days
    category_counts = count_category_spending_days(WEEKLY_DATA)
    print("\n📊 Days with Spending per Category (Count):")
    for category, count in category_counts.items():
        print(f"  - {category.capitalize()}: {count} day(s)")
        
    # Check Lucky Number (using the Grand Total, rounded down)
    lucky_check_number = int(grand_total)
    is_lucky = is_lucky_number(lucky_check_number)
    print(f"\n🍀 Lucky Number Check (using Grand Total {lucky_check_number}):")
    print(f"  - Is the number lucky (multiple of 7 or ends in 7)? **{is_lucky}**")

    # Reverse Description Example
    sample_description = "Movie tickets for the new blockbuster"
    reversed_desc = reverse_description(sample_description)
    print(f"\n🔄 Reverse Expense Description:")
    print(f"  - Original: '{sample_description}'")
    print(f"  - Reversed: '{reversed_desc}'")


    print("\nTracker session ended.")

    #Using emjois to enhance user engagement throughout the application.
    
# Reference:
#Google (2024) Gemini. Available at: https://gemini.google.com/
#(Accessed: 14 December 2025).