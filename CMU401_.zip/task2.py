class Expenses:
    def __init__(self, food, transport, entertainment, other):
        self.food = food
        self.transport = transport
        self.entertainment = entertainment
        self.other = other

#Start off by Defining a function to get daily expenses from the user
def get_daily_expense():
    print("🎯 Getting Daily Expense")
# Use input prompts to gather expense data
    food = float(input("Food expense: £"))
    transport = float(input("Transport expense: £"))
    entertainment = float(input("Entertainment expense: £"))
    other = float(input("Other expense: £"))

    return Expenses(food, transport, entertainment, other)


# Program starts here
print("🎯 Running Daily Expense Tracker!")

daily_expense = get_daily_expense()
# Display the collected daily expenses
print("📊 Daily Expenses")
print(f"Food: £{daily_expense.food}")
print(f"Transport: £{daily_expense.transport}")
print(f"Entertainment: £{daily_expense.entertainment}")
print(f"Other: £{daily_expense.other}")


 
# Reference:
#Google (2024) Gemini. Available at: https://gemini.google.com/
#(Accessed: 14 December 2025).       