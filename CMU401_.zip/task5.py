#Task 4's Code with added Weekly Budget commands, such as count_expenses, find_expenses,
#remove_expenses_by_amount

# Simple Expense and Budget Classes for Tracking

class Expense:
    
    #Represents a single expense item with details.
    
    def __init__(self, amount: float, description: str, category: str):
        # The amount spent
        self.amount = amount
        # A brief description of the expense
        self.description = description
        # The category (e.g., Food, Transport, Entertainment)
        self.category = category

    def __str__(self):
        #Returns a string representation of the Expense object."""
        return f"[{self.category:<13}] ${self.amount:7.2f} - {self.description}"


class WeeklyBudget:

    #Stores a list of Expense objects and provides methods for basic financial tracking.
    
    def __init__(self):
        # Expenses are stored in a simple list
        self.expenses = []

    def add_expense(self, expense: Expense):
        
        #Adds a new Expense object to the budget tracker.
        
        self.expenses.append(expense)
        print(f"💰 Added: {expense.description} (${expense.amount:.2f})")

    def show_totals(self) -> float:
        
        #Calculates and returns the total amount of all recorded expenses.
        
        total = sum(expense.amount for expense in self.expenses)
        return total
    
    def count_expenses(self) -> int:
        
        #Counts the total number of individual expenses recorded.
        
        return len(self.expenses)

    def find_expenses(self, query: str) -> list[Expense]:
        
        #Finds expenses where the description or category contains the query string (case-insensitive).
        #Returns a list of matching Expense objects.
        
        found = []
        q_lower = query.lower()
        for expense in self.expenses:
            # Check if the query is in the description OR category
            if q_lower in expense.description.lower() or q_lower in expense.category.lower():
                found.append(expense)
        return found
    
    def remove_expense(self, description: str) -> bool:
        
        #Removes the first expense found matching the description exactly (case-insensitive).
        #Returns True if an expense was removed, False otherwise.
        
        initial_count = len(self.expenses)
        # Filter the list, keeping only expenses that do NOT match the description
        self.expenses = [
            e for e in self.expenses if e.description.lower() != description.lower()
        ]
        
        return len(self.expenses) < initial_count
    
    def sort_expenses_by_amount(self, reverse: bool = True) -> list[Expense]:
        
        #Sorts expenses by amount. By default, sorts high to low (reverse=True).
        #This sorts the internal list of expenses in place.
        #Returns the sorted list of Expense objects.
        
        self.expenses.sort(key=lambda expense: expense.amount, reverse=reverse)
        return self.expenses


    def display_expenses(self):
        
        #Displays all recorded expenses nicely, grouped by category for readability.
        
        if not self.expenses:
            print("\n-- No expenses recorded this week. --")
            return

        print("\n--- WEEKLY EXPENSE BREAKDOWN ---")
        
        # Group expenses by category
        categories = {}
        for expense in self.expenses:
            if expense.category not in categories:
                categories[expense.category] = []
            categories[expense.category].append(expense)

        # Display expenses category by category
        for category, expense_list in categories.items():
            category_total = sum(e.amount for e in expense_list)
            print(f"\n[{category.upper()} - Total: ${category_total:.2f}]")
            print("-" * (len(category) + 20))
            for expense in expense_list:
                print(f"  - ${expense.amount:.2f}: {expense.description}")

        # Display the grand total at the end
        grand_total = self.show_totals()
        print("\n" + "="*30)
        print(f"✨ GRAND WEEKLY TOTAL: ${grand_total:.2f}")
        print("="*30)


if __name__ == "__main__":
    # Example usage demonstration
    
    # 1. Create a WeeklyBudget instance
    my_budget = WeeklyBudget()

    # 2. Add some expenses
    my_budget.add_expense(Expense(amount=12.50, description="Lunch at cafe", category="Food"))
    my_budget.add_expense(Expense(amount=4.75, description="Bus fare to work", category="Transport"))
    my_budget.add_expense(Expense(amount=35.00, description="Movie night out", category="Entertainment"))
    my_budget.add_expense(Expense(amount=5.00, description="Coffee and pastry", category="Food"))
    my_budget.add_expense(Expense(amount=75.00, description="New headphones", category="Other"))
    my_budget.add_expense(Expense(amount=9.99, description="Subscription fee", category="Other"))

    # 5. Count total number of expenses
    print(f"\n📊 Total number of expenses recorded: {my_budget.count_expenses()}")

    # 4. Sort expenses by amount (high to low)
    print("\n⬇️ Sorting expenses by amount (High to Low)...")
    my_budget.sort_expenses_by_amount(reverse=True)
    
    # Display all expenses to show the sorted list
    my_budget.display_expenses()
    
    # 2. Add function to find specific expenses
    query = "cafe"
    found_expenses = my_budget.find_expenses(query)
    print(f"\n🔎 Found {len(found_expenses)} expenses matching '{query}':")
    for expense in found_expenses:
        print(f"  - {expense}")
        
    # 3. Remove function to delete expenses
    item_to_remove = "Subscription fee"
    if my_budget.remove_expense(item_to_remove):
        print(f"\n🗑️ Successfully removed: {item_to_remove}")
    else:
        print(f"\n❌ Could not find expense to remove: {item_to_remove}")
        
    print(f"📊 Total number of expenses remaining: {my_budget.count_expenses()}")
    
    # 4. Show the grand total (updated after removal)
    final_total = my_budget.show_totals()
    print(f"Total after removal: ${final_total:.2f}")

    
# Reference:
#Google (2024) Gemini. Available at: https://gemini.google.com/
#(Accessed: 14 December 2025).
#Stack Overflow (2024) Stack Overflow: Where developers learn, share, and build careers. Available at: https://stackoverflow.com/
 #(Accessed: 14 December 2025).